// src/db/upsertResults.ts
import { supabaseAdmin } from './client';

export type ShoeResult = {
  brand_name: string;
  model: string;
  primary_use?: string | null;
  cushioning_type?: string | null;
  heel_height?: number | null;
  forefoot_height?: number | null;
  weight?: number | null;
  foot_width?: string | null;
  drop?: number | null;
  surface_type?: string | null;
  upper_breathability?: number | null;
  carbon_plate?: boolean | null;
  waterproof?: boolean | null;
  price?: number | null;
  additional_features?: string | null;
  source_link: string;
  article_id: string;
  date?: string | null; // 'YYYY-MM-DD'
};

/**
 * Upsert пачкой. Разрезает rows на куски (по умолчанию 500), чтобы не упереться в лимиты.
 * Идемпотентно по (article_id, source_link) — дубликатов не будет.
 */
export async function upsertResultsBatch(rows: ShoeResult[], chunk = 500) {
  if (!rows?.length) return;

  for (let i = 0; i < rows.length; i += chunk) {
    const part = rows.slice(i, i + chunk);

    const { error } = await supabaseAdmin
      .from('shoe_results')
      .upsert(part, { onConflict: 'article_id,source_link' });

    if (error) {
      // В реальном пайплайне лучше не бросать ошибку на весь процесс,
      // а логировать её в processing_errors и продолжать.
      throw new Error(
        `Upsert failed on chunk [${i}-${i + part.length - 1}]: ${error.message}`
      );
    }
  }
}
