// src/pipeline/saveToSupabase.ts
import { upsertResultsBatch, ShoeResult } from '../db/upsertResults';

/** Нормализация и приведение типов под схему таблицы */
function toShoeResult(raw: any): ShoeResult {
  const num = (v: any) => (v === null || v === undefined || v === '' ? null : Number(v));
  const bool = (v: any) => (v === null || v === undefined || v === '' ? null : Boolean(v));
  const str = (v: any) => (v === null || v === undefined ? null : String(v).trim());

  return {
    brand_name: String(raw.brand_name ?? raw.brand ?? '').trim(),
    model: String(raw.model ?? '').trim(),
    primary_use: str(raw.primary_use),
    cushioning_type: str(raw.cushioning_type),

    heel_height: num(raw.heel_height),
    forefoot_height: num(raw.forefoot_height),
    weight: num(raw.weight),
    foot_width: str(raw.foot_width),
    drop: num(raw.drop),
    surface_type: str(raw.surface_type),
    upper_breathability: num(raw.upper_breathability),

    carbon_plate: raw.carbon_plate === undefined ? null : bool(raw.carbon_plate),
    waterproof:   raw.waterproof   === undefined ? null : bool(raw.waterproof),
    price: num(raw.price),

    additional_features: str(raw.additional_features),
    source_link: String(raw.source_link ?? raw.url ?? '').trim(),
    article_id:  String(raw.article_id  ?? raw.id  ?? '').trim(),

    // ожидается формат 'YYYY-MM-DD'; если у вас ISO — возьмём первые 10 символов
    date: raw.date ? String(raw.date).slice(0, 10) : null,
  };
}

/** Публичная функция: передайте сюда массив ваших итоговых записей */
export async function saveToSupabase(finalRows: any[]) {
  // фильтруем мусор: без brand_name/model/source_link/article_id в базу не пишем
  const cleaned = finalRows
    .map(toShoeResult)
    .filter(r => r.brand_name && r.model && r.source_link && r.article_id);

  if (!cleaned.length) {
    console.log('saveToSupabase: nothing to save');
    return;
  }

  // batched upsert (идемпотентно по (article_id, source_link))
  await upsertResultsBatch(cleaned, 500);
  console.log(`saveToSupabase: upserted ${cleaned.length} rows`);
}
